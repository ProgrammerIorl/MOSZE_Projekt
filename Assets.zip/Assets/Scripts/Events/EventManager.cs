
using UnityEngine;
using UnityEngine.Events;
public static class EventManager
{
    public static event UnityAction StageEnd;
    public static event UnityAction Pause;
 
    public static void OnStageEnd() => StageEnd?.Invoke();
    public static void OnPause() => Pause?.Invoke();

}
